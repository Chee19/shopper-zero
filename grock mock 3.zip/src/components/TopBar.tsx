import type { ReactNode } from "react"
import { Mark } from "./Mark"

export function TopBar({
  start,
  center,
  end,
  onBrand,
}: {
  start?: ReactNode
  center?: ReactNode
  end?: ReactNode
  onBrand?: () => void
}) {
  const brand = (
    <>
      <Mark />
      <span>
        Grok Buy
        <small>Agent checkout</small>
      </span>
    </>
  )
  return (
    <header className="top">
      <div className="top-start">
        {start}
      {onBrand ? (
        <button type="button" className="brand" onClick={onBrand}>
          {brand}
        </button>
      ) : (
        <div className="brand">{brand}</div>
      )}
      </div>
      <div className="center">{center}</div>
      <div className="end">{end}</div>
    </header>
  )
}
