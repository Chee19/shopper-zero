export type VersionId = "issues" | "solution"

export function ModeToggle({
  technical,
  onTechnical,
}: {
  technical: boolean
  onTechnical: (technical: boolean) => void
}) {
  return (
    <div className="mode-toggle" role="group" aria-label="Non technical or technical">
      <button type="button" className={technical ? "" : "on"} onClick={() => onTechnical(false)}>
        Non technical
      </button>
      <button type="button" className={technical ? "on" : ""} onClick={() => onTechnical(true)}>
        Technical
      </button>
    </div>
  )
}
