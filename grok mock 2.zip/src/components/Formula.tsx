import { CHECKOUT_RATE, formatEuro, formatInt, type Money } from "../model"

export function Formula({ money }: { money: Money }) {
  return (
    <p className="formula">
      {formatInt(money.visits)} visits × {Math.round(CHECKOUT_RATE * 100)} in 100 who order × the{" "}
      {money.gapPercent}% Grok cannot finish × {formatEuro(money.aov)}
    </p>
  )
}
