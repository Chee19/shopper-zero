import { CHECKOUT_RATE, FEE_RATE, formatEuro, formatInt, formatOrders, paybackLabel, type Money, type Report } from "../model"

export function Solution({ report, money, onBuy }: { report: Report; money: Money; onBuy: () => void }) {
  const feePercent = Math.round(FEE_RATE * 100)
  return (
    <div className="solution">
      <p className="eyebrow">The fix</p>
      <h2>Three changes, then Grok can finish the purchase.</h2>
      <ol className="simple-fixes">
        {report.worst.map((node, index) => (
          <li key={node.id}>
            <strong>
              {index + 1}. {node.label}
              <em>{node.score}%</em>
            </strong>
            <span>{node.fix}</span>
          </li>
        ))}
      </ol>

      <section className="money-panel">
        <h3>What this shop is missing</h3>
        <p className="money-note">
          Estimated for {report.host}: about {formatInt(money.visitsPerDay)} visits a day, and about{" "}
          {formatEuro(money.aov)} a sale. {Math.round(CHECKOUT_RATE * 100)} in 100 visits place an order. Grok finishes{" "}
          {report.overall}% of those. A person finishes {report.humanOverall}%.
        </p>
        <ul className="money-math">
          <li>
            <span>About {formatInt(money.visitsPerDay)} visits a day</span>
            <strong>{formatInt(money.visits)} a month</strong>
          </li>
          <li>
            <span>{Math.round(CHECKOUT_RATE * 100)} in 100 start checkout</span>
            <strong>{formatOrders(money.wouldBuy)} orders</strong>
          </li>
          <li>
            <span>Grok drops {money.gapPercent}% of them</span>
            <strong>{formatOrders(money.lostOrders)} never finish</strong>
          </li>
          <li>
            <span>At about {formatEuro(money.aov)} each</span>
            <strong>{formatEuro(money.lostMoney)} missed</strong>
          </li>
        </ul>
        <p className="money-hero">
          <strong>{formatEuro(money.lift)}</strong>
          <span>extra each month if these three are fixed. {paybackLabel(money.paybackDays)}</span>
        </p>
        <p className="money-sub">
          Over a year that is about {formatEuro(money.yearlyLoss)} that never gets ordered. The charge is{" "}
          {formatEuro(money.fee)}, {feePercent}% of the extra this shop would make each month.
        </p>
      </section>

      <button type="button" className="btn dark xl" onClick={onBuy}>
        <span>Fix this</span>
        <strong>
          {formatEuro(money.fee)} · {feePercent}% of the extra
        </strong>
      </button>
      <p className="quiet">This is a demo. Nothing is charged.</p>
    </div>
  )
}
