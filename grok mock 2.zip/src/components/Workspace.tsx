import { useEffect, useState } from "react"
import { formatEuro, type Money, type Report, type ShopUrl, type WorkflowNode } from "../model"
import { KpiTile, ReachChart, StepBars } from "./Charts"
import { DeepReport } from "./DeepReport"
import { RefreshIcon } from "./Icons"
import { SiteFrame } from "./SiteFrame"
import type { VersionId } from "./SideBar"
import { Solution } from "./Solution"
import { StepPanel } from "./StepPanel"
import { TopBar } from "./TopBar"
import { WorkflowMap } from "./WorkflowMap"

const STEP_MS = 1080

export function Workspace({
  shop,
  report,
  money,
  technical,
  alreadyGenerated,
  onBuy,
  onNewShop,
  onGenerated,
  onRescan,
  version,
  onVersion,
}: {
  shop: ShopUrl
  report: Report
  money: Money
  technical: boolean
  alreadyGenerated: boolean
  onBuy: () => void
  onNewShop: () => void
  onGenerated: () => void
  onRescan: () => void
  version: VersionId
  onVersion: (version: VersionId) => void
}) {
  const nodes = report.nodes
  const [generating, setGenerating] = useState(!alreadyGenerated)
  const [revealed, setRevealed] = useState(alreadyGenerated ? nodes.length : 0)
  const [run, setRun] = useState(0)
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [openId, setOpenId] = useState<string | null>(alreadyGenerated ? report.worst[0]?.id ?? null : null)

  useEffect(() => {
    if (!generating) return
    let cancelled = false
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches
    const sleep = (ms: number) => new Promise((resolve) => window.setTimeout(resolve, ms))
    async function play() {
      setRevealed(0)
      setSelectedId(null)
      await sleep(reduce ? 50 : 650)
      for (let i = 0; i < nodes.length; i++) {
        if (cancelled) return
        setRevealed(i + 1)
        setOpenId(nodes[i].id)
        await sleep(reduce ? 60 : STEP_MS)
      }
      await sleep(reduce ? 60 : 520)
      if (cancelled) return
      setGenerating(false)
      setOpenId(report.worst[0]?.id ?? null)
      setSelectedId(report.worst[0]?.id ?? null)
      onVersion("issues")
      onGenerated()
    }
    void play()
    return () => {
      cancelled = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [generating, run])

  const shown = nodes.slice(0, revealed)
  const active = generating ? nodes[Math.max(0, revealed - 1)] : null
  const partial = shown.length
    ? Math.round(shown.reduce((sum, node) => sum + node.score, 0) / shown.length)
    : 0
  const stuck = nodes.filter((node) => !node.ok).sort((a, b) => a.score - b.score)

  function replay() {
    onRescan()
    onVersion("issues")
    setGenerating(true)
    setRun((value) => value + 1)
  }

  function pick(id: string | null) {
    setSelectedId(id)
    setOpenId(id)
  }

  return (
    <section className={technical ? "workspace" : "workspace simple"}>
      <TopBar
        onBrand={onNewShop}
        end={
          <button type="button" className="round" aria-label="Scan again" disabled={generating} onClick={replay}>
            <RefreshIcon />
          </button>
        }
      />
      {technical ? (
        <TechnicalDash
          shop={shop}
          report={report}
          money={money}
          nodes={nodes}
          shown={shown}
          active={active}
          partial={partial}
          generating={generating}
          revealed={revealed}
          selectedId={selectedId}
          openId={openId}
          onSelect={pick}
          onBuy={onBuy}
        />
      ) : (
        <div className="simple-layout">
          {version === "solution" && !generating ? (
            <Solution report={report} money={money} onBuy={onBuy} />
          ) : generating ? (
            <>
              <SiteFrame shop={shop} node={active} nodes={shown} progress={partial} generating />
              <p className="simple-live">
                Checking {shop.host}. Step {Math.max(revealed, 1)} of {nodes.length}.
              </p>
            </>
          ) : (
            <Issues report={report} stuck={stuck} onSolution={() => onVersion("solution")} />
          )}
        </div>
      )}
    </section>
  )
}

function TechnicalDash({
  shop,
  report,
  money,
  nodes,
  shown,
  active,
  partial,
  generating,
  revealed,
  selectedId,
  openId,
  onSelect,
  onBuy,
}: {
  shop: ShopUrl
  report: Report
  money: Money
  nodes: WorkflowNode[]
  shown: WorkflowNode[]
  active: WorkflowNode | null
  partial: number
  generating: boolean
  revealed: number
  selectedId: string | null
  openId: string | null
  onSelect: (id: string | null) => void
  onBuy: () => void
}) {
  return (
    <div className="tech">
      <div className="kpis">
        <KpiTile value={generating ? partial : report.overall} format={percent} label="Grok finishes" good={(generating ? partial : report.overall) >= 64} />
        <KpiTile value={report.humanOverall} format={percent} label="A person finishes" good />
        <KpiTile value={money.lift} format={formatEuro} label="Extra each month" good />
        <KpiTile value={money.fee} format={formatEuro} label="7% of that extra" good={false} onClick={generating ? undefined : onBuy} />
      </div>
      <div className="ws-grid">
        <StepPanel
          nodes={nodes}
          revealed={revealed}
          selectedId={selectedId}
          openId={openId}
          generating={generating}
          onSelect={(id) => onSelect(id)}
          onOpen={onSelect}
        />
        <div className="ws-map-col">
          {generating ? (
            <SiteFrame shop={shop} node={active} nodes={shown} progress={partial} generating />
          ) : (
            <WorkflowMap
              nodes={nodes}
              revealed={nodes.length}
              tokenIndex={null}
              showToken={false}
              selectedId={selectedId}
              dimGroup={null}
              onSelect={onSelect}
            />
          )}
        </div>
      </div>
      {!generating && (
        <>
          <div className="tech-charts">
            <article className="card">
              <h2>Each step</h2>
              <p className="section-copy">Grey is a person. Green or red is Grok.</p>
              <StepBars nodes={nodes} />
            </article>
            <article className="card">
              <h2>How far a purchase gets</h2>
              <p className="section-copy">The line drops where Grok gets stuck. The pale line is after the three fixes.</p>
              <ReachChart nodes={nodes} />
            </article>
          </div>
          <DeepReport report={report} money={money} onBuy={onBuy} />
        </>
      )}
    </div>
  )
}

function percent(value: number): string {
  return `${Math.round(value)}%`
}

function Issues({
  report,
  stuck,
  onSolution,
}: {
  report: Report
  stuck: WorkflowNode[]
  onSolution: () => void
}) {
  return (
    <div className="issues">
      <p className="eyebrow">Issues</p>
      <h2>
        {stuck.length === 0
          ? "Grok can finish a purchase here."
          : `${stuck.length} places stop the purchase.`}
      </h2>
      <p className="simple-score">
        Grok finishes <strong>{report.overall}%</strong>. A person finishes {report.humanOverall}%.{" "}
        {report.working} of {report.nodes.length} steps work.
      </p>
      <ol className="issue-list">
        {stuck.map((node) => {
          const broken = node.checks.filter((check) => check.status === "error")
          return (
            <li key={node.id}>
              <div className="issue-top">
                <strong>{node.label}</strong>
                <em>{node.score}%</em>
              </div>
              <p>{broken[0] ? `${broken[0].label}. ${broken[0].detail}.` : node.fix}</p>
            </li>
          )
        })}
      </ol>
      {stuck.length > 0 && (
        <button type="button" className="btn dark xl" onClick={onSolution}>
          See the solution
        </button>
      )}
    </div>
  )
}
