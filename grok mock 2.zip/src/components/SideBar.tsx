export type VersionId = "issues" | "solution"

const PAGES: { id: VersionId; label: string }[] = [
  { id: "issues", label: "Issues" },
  { id: "solution", label: "Solution" },
]

export function SideBar({
  version,
  technical,
  hasReport,
  ready,
  onVersion,
  onTechnical,
}: {
  version: VersionId
  technical: boolean
  hasReport: boolean
  ready: boolean
  onVersion: (version: VersionId) => void
  onTechnical: (technical: boolean) => void
}) {
  return (
    <aside className="nav-side">
      <p className="nav-label">Pages</p>
      <nav className="nav-pages" aria-label="Pages">
        {PAGES.map((item) => {
          const locked = technical || !hasReport || (item.id === "solution" && !ready)
          return (
            <button
              key={item.id}
              type="button"
              className={hasReport && version === item.id ? "on" : ""}
              disabled={locked}
              aria-current={hasReport && version === item.id ? "page" : undefined}
              onClick={() => onVersion(item.id)}
            >
              {item.label}
            </button>
          )
        })}
      </nav>
      <div className="nav-settings">
        <p className="nav-label">Settings</p>
        <div className="nav-mode" role="group" aria-label="Non technical or technical">
          <button type="button" className={technical ? "" : "on"} onClick={() => onTechnical(false)}>
            Non technical
          </button>
          <button type="button" className={technical ? "on" : ""} onClick={() => onTechnical(true)}>
            Technical
          </button>
        </div>
      </div>
    </aside>
  )
}
